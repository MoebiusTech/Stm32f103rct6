#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

#define KEY1 PBin(12)
#define KEY2 PBin(14)
#define KEY3 PBin(14)
#define KEY4 PBin(14)

void KEY_Init(void);          //������ʼ��

#endif 
