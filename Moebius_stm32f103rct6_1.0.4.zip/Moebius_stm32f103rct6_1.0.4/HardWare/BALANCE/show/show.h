#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"
  /**************************************************************************
���ߣ�ī��˹�Ƽ�
�ҵ��Ա�С�꣺https://moebius.taobao.com/
**************************************************************************/
void oled_show(void);
void APP_Show(void);
void DataScope(void);
#endif
