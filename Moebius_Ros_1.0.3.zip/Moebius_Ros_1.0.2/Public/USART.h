#ifndef _USART_H_
#define _USART_H_

#include "Sys.h" 
#include "stdio.h" 

void USART1_Init(u32 bound);


#endif


