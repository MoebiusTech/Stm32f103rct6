#ifndef _Systick_H
#define _Systick_H

#include "Sys.h"

void delay_us(u32 i);
void delay_ms(u32 i);

#endif

